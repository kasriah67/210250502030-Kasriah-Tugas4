
package VolumeSuara;


public class If_Kondisi2 {
     public static void main(String[] args) {
        
        int volume ;
        
        volume = 20 ;
        
        if ( volume <= 30) {
            System.out.println("Volume Suara Rendah");
        } else if (volume <=60 ) {
            System.out.println("Volume suara sedang");
        } else {
            System.out.println("Volume suara tinggi");
        }
        
}
}