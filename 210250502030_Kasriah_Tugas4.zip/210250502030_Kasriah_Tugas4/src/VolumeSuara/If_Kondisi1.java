
package VolumeSuara;


public class If_Kondisi1 {
    public static void main(String[] args) {
        
        int volume ;
        
        volume = 20 ;
        
        if ( volume <= 50) {
            System.out.println("Volume Suara Rendah");
        } else {
            System.out.println("Volume suara tinggi");
        }
        
    
    }
}
